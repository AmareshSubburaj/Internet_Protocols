import platform
import socket
import pickle
from thread import *
import time

# initialize, bind, listen
server_port_num = 7734
server_address = str(raw_input("Enter Server Address: " + "\n"))

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((server_address, server_port_num))
server_socket.listen(5)

# create dictionaries globals

listdic_ky_rfcnum_val_lpeers = {}
listdic_ky_rfcnum_val_rfctitle = {}
listdic_ky_host_val_port = {}


# list message format

def status_line(num):
    if (num == "200"): reply = "OK"

    if (num == "400"): reply = "Bad request"

    if (num == "404"): reply = "Not Found"

    message = "P2P-CI/1.0 " + str(num) + " " + reply + "\n"

    return message


def create_list_response():
    temp_message = ""
    temp_message_list = []
    global listdic_ky_rfcnum_val_lpeers
    global listdic_ky_rfcnum_val_rfctitle
    global listdic_ky_host_val_port

    if not listdic_ky_rfcnum_val_lpeers:
        return status_line("404")
    else:
        for rfc_num, lpeers in listdic_ky_rfcnum_val_lpeers.items():
            for peer in lpeers:
                line = str(rfc_num) + " " + str(listdic_ky_rfcnum_val_rfctitle[rfc_num]) + " " + str(peer) + " " + str(
                    listdic_ky_host_val_port[peer]) + "\n"
                temp_message_list.append(line)
        temp_message_list.insert(0, status_line("200"))

        for itr in temp_message_list:
            temp_message = temp_message + itr

        return temp_message


def create_loopup_reponse(rfc_num_lookup):
    temp_message = ""
    temp_message_list = []
    global listdic_ky_rfcnum_val_lpeers
    global listdic_ky_rfcnum_val_rfctitle
    global listdic_ky_host_val_port

    if not listdic_ky_rfcnum_val_lpeers:
        return status_line("404")
    elif rfc_num_lookup in listdic_ky_rfcnum_val_lpeers:
        lpeer = []
        lpeer = listdic_ky_rfcnum_val_lpeers.get(rfc_num_lookup)
        for peer in lpeer:
            line = str(rfc_num_lookup) + " " + str(listdic_ky_rfcnum_val_rfctitle[rfc_num_lookup]) + " " + str(
                peer) + " " + str(listdic_ky_host_val_port[peer]) + "\n"
            temp_message_list.append(line)
        temp_message_list.insert(0, status_line("200"))

        for itr in temp_message_list:
            temp_message = temp_message + itr

        return temp_message
    else:
        return status_line("404")


def create_get_reponse(rfc_num_lookup):
    temp_message_list = []
    global listdic_ky_rfcnum_val_lpeers
    global listdic_ky_rfcnum_val_rfctitle
    global listdic_ky_host_val_port

    current_time = time.strftime("%a, %d %b %Y %X %Z", time.localtime())

    if not listdic_ky_rfcnum_val_lpeers:
        temp_message_list.append(str(
            status_line("404") + " " + "Date:" + str(current_time) + "\n" + "OS:" + str(platform.platform()) + "\n"))
        return temp_message_list
    elif rfc_num_lookup in listdic_ky_rfcnum_val_lpeers:
        lpeer = []
        lpeer = listdic_ky_rfcnum_val_lpeers.get(rfc_num_lookup)
        line = str(rfc_num_lookup) + " " + str(listdic_ky_rfcnum_val_rfctitle[rfc_num_lookup]) + " " + str(
            lpeer[0]) + " " + str(listdic_ky_host_val_port[lpeer[0]]) + "\n"
        line = str(status_line("200")) + line
        temp_message_list.append(line)
        temp_message_list.append(lpeer[0])
        temp_message_list.append(listdic_ky_host_val_port[lpeer[0]])
        return temp_message_list
    else:
        temp_message_list.append(str(
            status_line("404") + "\n" + "Date:" + str(current_time) + "\n" + "OS:" + str(platform.platform()) + "\n"))
        return temp_message_list


def remove_client_fromdatastructures(client_address):
    remove_rfcs_list = []
    global listdic_ky_rfcnum_val_lpeers
    global listdic_ky_rfcnum_val_rfctitle
    global listdic_ky_host_val_port

    for rtc_num, lpeers in listdic_ky_rfcnum_val_lpeers.items():
        for peers in lpeers:
            if peers == client_address:
                lpeers.remove(client_address)
            if not lpeers:
                listdic_ky_rfcnum_val_rfctitle.pop(rtc_num)  # if no peer list found remove from rfc data base.

    for rtc_num, lpeers in listdic_ky_rfcnum_val_lpeers.items():
        if not lpeers:
            remove_rfcs_list.append(rtc_num)

    for rfc_num in remove_rfcs_list:
        listdic_ky_rfcnum_val_lpeers.pop(rfc_num)

    listdic_ky_host_val_port.pop(client_address)


def create_add_response(port_num, hostname, rfc_num, rfc_title):
    return "P2P-CI/1.0 200 OK" + " " + str(rfc_num) + " " + str(rfc_title) + " " + str(hostname) + " " + str(
        port_num) + "\n"


###############################################################################################

def respond_to_clientfn(socket_obj, client_address):
    global listdic_ky_rfcnum_val_lpeers
    global listdic_ky_rfcnum_val_rfctitle
    global listdic_ky_host_val_port

    unpickled_data = socket_obj.recv(2048)
    data = pickle.loads(unpickled_data)
    str_action = data[0]
    peer_addr = data[1]

    peer_port_num = data[2]
    list_rfc_num = data[3]
    list_rfc_title = data[4]
    print("The client address" + str(client_address) + "\n")

    if str_action == 'INITIALIZE':

        # load into listdic_ky_host_val_port
        if peer_addr not in listdic_ky_host_val_port:
            listdic_ky_host_val_port[peer_addr] = peer_port_num
        # load into listdic_ky_rfcnum_val_rfctitle
        for rfc_num, rfc_title in zip(list_rfc_num, list_rfc_title):
            if rfc_num not in listdic_ky_rfcnum_val_rfctitle:
                listdic_ky_rfcnum_val_rfctitle[rfc_num] = rfc_title
        # load into listdic_ky_rfcnum_val_lpeers

        for rfc_num in list_rfc_num:
            if rfc_num in listdic_ky_rfcnum_val_lpeers:
                lpeers = listdic_ky_rfcnum_val_lpeers[rfc_num]
                if peer_addr not in lpeers:
                    listdic_ky_rfcnum_val_lpeers[rfc_num].append(peer_addr)
            else:
                listdic_ky_rfcnum_val_lpeers[rfc_num] = []
                listdic_ky_rfcnum_val_lpeers[rfc_num].append(peer_addr)

        print("processing Initialize request" + "\n")

        print("\n" + "listdic_ky_rfcnum_val_lpeers")
        print(listdic_ky_rfcnum_val_lpeers)
        print("\n" + "listdic_ky_rfcnum_val_rfctitle")
        print(listdic_ky_rfcnum_val_rfctitle)
        print("\n" + "listdic_ky_host_val_port")
        print(listdic_ky_host_val_port)

    while True:
        unpickled_data = socket_obj.recv(2048)

        if unpickled_data != "":
            data = pickle.loads(unpickled_data)
            str_action = str(data[0])

            if str_action == 'LIST':
                client_request_message = data[1]
                print("processing List request\n")
                print(client_request_message)
                LIST_message = create_list_response()
                socket_obj.send(LIST_message)

            if str_action == 'LOOKUP':
                rfc_num_lookup = str(data[1])
                client_request_message = data[2]
                print("processing lookup request\n")
                print(client_request_message)
                LOOKUP_message = create_loopup_reponse(rfc_num_lookup)
                socket_obj.send(LOOKUP_message)

            if str_action == 'GET':
                rfc_num_get = str(data[1])
                client_request_message = data[2]
                print("processing GET request\n")
                print(client_request_message)
                GET_Message = []
                GET_Message = create_get_reponse(rfc_num_get)

                pickled_data = pickle.dumps(GET_Message)
                socket_obj.send(pickled_data)

            if (str_action == 'ADD'):

                rfc_num_add = str(data[1])
                rfc_num_title = str(data[2])
                client_address = str(data[3])
                client_request_message = str(data[4])
                print("processing ADD request\n")
                print(client_request_message)

                if rfc_num_add not in listdic_ky_rfcnum_val_lpeers:
                    list_peers = []
                    list_peers.append(client_address)
                    listdic_ky_rfcnum_val_lpeers[rfc_num_add] = list_peers
                else:
                    #   if rfc_num_add not in listdic_ky_rfcnum_val_lpeers:
                    listdic_ky_rfcnum_val_lpeers[rfc_num_add].append(client_address)
                    if rfc_num_add not in listdic_ky_rfcnum_val_rfctitle:
                        listdic_ky_rfcnum_val_rfctitle[rfc_num_add] = rfc_num_title

                listdic_ky_rfcnum_val_rfctitle[rfc_num_add] = rfc_num_title
                ADD_Message = create_add_response(peer_port_num, client_address, rfc_num_add, rfc_num_title)
                pickled_data = pickle.dumps(ADD_Message)
                socket_obj.send(pickled_data)

            if str_action == 'EXIT':
                print("The client address" + str(client_address) + " exiting.............." + "\n")
                client_address = str(data[1])
                remove_client_fromdatastructures(client_address)
                print(listdic_ky_host_val_port)
                print(listdic_ky_rfcnum_val_lpeers)
                print(listdic_ky_rfcnum_val_rfctitle)
                break

    socket_obj.close()


# accept connections on the specified sockets and create seperate thread to handle each request
while True:
    socket_obj, client_address = server_socket.accept()
    start_new_thread(respond_to_clientfn, (socket_obj, client_address))
