import platform
import random
import os
import socket
import pickle
from thread import *
import time

server_address =  str(raw_input("Enter Server Address: " + "\n"))
server_port_num = 7734
client_address = str(raw_input("Enter Client Address: " + "\n"))
client_upload_port_num =  61000 + random.randint(1,1000)

# global variables
list_rfc_num = []
list_rfc_title = []
rfc_path = os.getcwd() + "/rfc/"
Exit_peer_peer_thread = False

def get_rfc_num():    # makes local rfc numbers into a list
    list_rfcs_numbers = []
    for num in os.listdir(rfc_path):
        num = num[num.find('c') + 1:num.find('.')]
        list_rfcs_numbers.append(num)
    return list_rfcs_numbers

def get_rfc_title():   #makes local rfc file names into titles.
    list_rfcs_titles = []
    for num in os.listdir(rfc_path):
        list_rfcs_titles.append(num[:num.find('.')])
    return list_rfcs_titles


def sendinfo_to_server_at_start(): # sends hostname, host port number , rfc numbers and rfc titles

    global list_rfc_num
    list_rfc_num = get_rfc_num()
    global list_rfc_title
    list_rfc_title = get_rfc_title()
    return ["INITIALIZE", str(client_address) , str(client_upload_port_num) ,list_rfc_num , list_rfc_title]

#create client socket and connect to server then send  my  hostname port  rfcs available.
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((server_address, server_port_num))

initialize_data = pickle.dumps( sendinfo_to_server_at_start() )
client_socket.send(initialize_data)    #list of values sent to server




def get_rfcfile_from_fellowpeers( rfc_num, contact_peer_address, contact_peer_port_num ):
    print "Inside rfcfile_from_fellowpeers"
    client_peer_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_peer_socket.connect((contact_peer_address, int(contact_peer_port_num)))
    message=[]
    message.append(str(rfc_num))
    message.append( "GET "+str(rfc_num)+" P2P-CI/1.0 "+ " Host: "+str(client_address)+" " +" OS: "+platform.platform() + "\n")
    pickled_data = pickle.dumps(message)
    client_peer_socket.send(pickled_data)
    pickled_data = client_peer_socket.recv(1073741824)
    data = pickle.loads(pickled_data)

    if len(data) == 1:
        print data[0]   #message
    else:
        print data[0]
        fname = rfc_path  +'rfc'+ str(rfc_num) + ".txt"
        file_obj = open(fname, 'w')
        file_obj.write(data[1])
    client_peer_socket.close()


def Client_input():

 global Exit_peer_peer_thread
 if Exit_peer_peer_thread == True:
     return 0

 print "\n"

 while True:

    Response = raw_input("Enter Client Response: LIST, LOOKUP, ADD, GET, EXIT: " + "\n").upper()

    if Response == 'LIST':
        print "User input: LIST"
        message =[]
        message.append('LIST')
        message.append("LIST ALL P2P-CI/1.0 " + "\nHost: " + str(client_address) + " " + "\nPort: " + str(client_upload_port_num) + "\n")
        list_data = pickle.dumps(message)
        client_socket.send(list_data)
        data = client_socket.recv(2048)
        print(data)





    if Response == 'LOOKUP':

        print "User input: LOOKUP:"

        rfc_num = str(raw_input("Enter the rfc number to lookup:: ")).lower()
        rfc_num_title = raw_input("Enter the rfc number title:: ").lower()
        message =[]
        message.append('LOOKUP')
        message.append(rfc_num)
        message.append("LOOKUP "+str(rfc_num)+" P2P-CI/1.0 " +  "\nHost: "+str(client_address)+" " + "\nPort: "+str(client_upload_port_num)+" " + "\nTitle: "+str(rfc_num_title) + "\n")
        lookup_data = pickle.dumps(message)
        client_socket.send(lookup_data)
        data = client_socket.recv(2048)
        print(data)



    if Response == 'ADD':
        print "User input: ADD"

        rfc_num = str(raw_input("Enter the rfc number to add::")).lower()
        rfc_num_title = str(raw_input("Enter the rfc number title::")).lower()
        global list_rfc_num
        list_rfc_num = get_rfc_num()
        global list_rfc_title
        list_rfc_title = get_rfc_title()

        if rfc_num not in list_rfc_num:
            print "rfc file not in client's base"
        else:
            message = []
            message.append('ADD')
            message.append( rfc_num )
            message.append( rfc_num_title)
            message.append( client_address)
            message.append( "ADD " + str(rfc_num)+" P2P-CI/1.0" +" "+ "\nHost:" + str(client_address) + " " + "\nPort:" +str(client_upload_port_num)+ " " + "\nTitle: "+ " " +str(rfc_num_title) + "\n")
            add_data = pickle.dumps(message)
            client_socket.send(add_data)

            pickled_data = client_socket.recv(2048)
            unpickled_data = pickle.loads(pickled_data)
            print(unpickled_data)



    if Response == 'GET':
        print "User input: GET"
        rfc_num = str(raw_input("Enter the rfc number to get::")).lower()
        rfc_num_title = str(raw_input("Enter the rfc number title::")).lower()
        message = []
        message.append('GET')
        message.append( rfc_num )
        message.append( "GET "+str(rfc_num)+" "+str(client_address)+" "+str(client_upload_port_num)+" "+str(rfc_num_title) )
        get_data = pickle.dumps(message)
        client_socket.send(get_data)

        pickled_data = client_socket.recv(2048)
        unpickled_data = pickle.loads(pickled_data)
        Message_List =[]
        Message_List = unpickled_data
        print (len(Message_List))

        if len(Message_List)==1:
           print(Message_List[0])
        else:
           print(Message_List)
           contact_peer_address = Message_List[1]
           print(Message_List[1])
           contact_peer_port_num = Message_List[2]
           print(Message_List[2])
           get_rfcfile_from_fellowpeers( rfc_num, contact_peer_address, contact_peer_port_num )
           # contact server to update its database
           message = []
           message.append('ADD')
           message.append( rfc_num )
           message.append( rfc_num_title)
           message.append( client_address)
           message.append( "ADD " + str(rfc_num)+" P2P-CI/1.0" +" "+ "\nHost:" + str(client_address) + " " + "\nPort:" +str(client_upload_port_num)+ " " + "\nTitle: "+ " " +str(rfc_num_title) + "\n")
           add_data = pickle.dumps(message)
           client_socket.send(add_data)

           pickled_data = client_socket.recv(2048)
           unpickled_data = pickle.loads(pickled_data)
           print(unpickled_data)





    if Response == 'EXIT':
        print "The Client is closing the connection " + str(client_address) + "\n"
        message = []
        message.append('EXIT')
        message.append(client_address)
        pickled_data = pickle.dumps(message)
        client_socket.send(pickled_data)
        Exit_peer_peer_thread = True
        client_socket.close()
        break

    if Response not in ['EXIT', 'GET' , 'ADD', 'LOOKUP' , 'LIST']:
        print "UNKNOWN REQUEST"




def respond_peer_to_peer_thread():
    global Exit_peer_peer_thread
    print "Peer to Peer thread" +"\n"
    P2P_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    P2P_socket.bind((client_address, int(client_upload_port_num)))
    P2P_socket.listen(5)
    message =[]
    while True:

        if Exit_peer_peer_thread == True:
           print("exiting respond peer to peer" + "\n")
           P2P_socket.close()
           break


        socket_obj, addr = P2P_socket.accept()

        print('Accepted connection' + '\n')

        unpickled_data = socket_obj.recv(2048)
        data = pickle.loads(unpickled_data)
        rfc_num = data[0]
        print data[1]

        rfc_2sendpath = rfc_path + 'rfc' + str(rfc_num)+".txt"

        current_time = time.strftime("%a, %d %b %Y %X %Z", time.localtime())

        if os.path.isfile(rfc_2sendpath):
          content_length = os.path.getsize(rfc_2sendpath)
          message.append("P2P-CI/1.0 200 OK  " + "\nDate: " + str(current_time) + " " + "\nOS: " + str(platform.platform()) + "  " + "\nLast-Modified: " + str(time.ctime(os.path.getmtime(rfc_2sendpath))) + "  "+"\nContent-Length:" + str(content_length) + "  " \
                                                                                               "\nContent-Type: text/text \n")
          file=  open(rfc_2sendpath, 'r')
          data = file.read()
          message.append(str(data))
          pickled_data = pickle.dumps(message)
          socket_obj.send(pickled_data)
          file.close()



        else:
          message.append("P2P-CI/1.0 404 Not Found  " + "\nDate: " + str(current_time) + "  " + "\nOS: " + str(platform.platform()) + "\n")
          pickled_data = pickle.dumps(message)
          socket_obj.send(pickled_data)
    socket_obj.close()




start_new_thread( respond_peer_to_peer_thread, ())

if Exit_peer_peer_thread == True:
 exit()

Client_input()






