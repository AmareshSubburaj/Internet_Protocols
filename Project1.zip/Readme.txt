
1)Run the server present in Folder Client_p2p_1 using the command.

python server.py

2)Enter the server address for server initialization.


3)Run the clients present in Folders Client_p2p_1 and Client_p2p_2 using the command

python client.py

4)Enter the server and client address respectively for client initialization.

5)Use the Requests available in the clients terminal to interact with the server.


6)Use EXIT available in clients to terminate clients. Ctrl+C also works but not recommended.

use ps -FA| grep python 

to get process running python and use "kill processno" to terminate the process
